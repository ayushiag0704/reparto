package com.example.ayagrawa.myapplication;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.widget.VideoView;

import java.io.File;

public class MainActivity extends AppCompatActivity {


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        Intent newint = new Intent(MainActivity.this,PlayActivity.class);
        startActivity(newint);
    }

}

 class PlayActivity extends AppCompatActivity
{
    private Button playBtn;
    File[] files;
    int counter = 0;
    private ProgressBar spinner;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        playBtn = (Button) findViewById(R.id.play);
        checkPermissions();
//        updateList();
        spinner = (ProgressBar)findViewById(R.id.progressBar1);
        spinner.setVisibility(View.GONE);
        playBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (ActivityCompat.checkSelfPermission(PlayActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    playBtn.setVisibility(View.GONE);
//                    playVideo();
                    updateList();
                } else
                    checkPermissions();
            }
        });
    }

    private void checkPermissions() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
    }

    private void playVideo() {


//             for(int i=0; i<files.length; i++) {
        if (files.length > counter) {
            VideoView videoView = (VideoView) findViewById(R.id.VideoView);
            MediaController mediaController = new MediaController(this);
            mediaController.setAnchorView(videoView);

            //specify the location of media file
            String pathnew = Environment.getExternalStorageDirectory().getAbsolutePath() + "/test/" + files[counter].getName();
            // Toast.makeText(this, pathnew, Toast.LENGTH_LONG).show();
            Uri uri = Uri.parse(pathnew);
            videoView.setMediaController(mediaController);
            videoView.setVideoURI(uri);
            // videoView.requestFocus();
            videoView.start();
            videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    counter = counter + 1;
                    playVideo();
                }
            });
            //System.out.println(path);
//             }
        }else{
            // Toast.makeText(this,"All Done",Toast.LENGTH_LONG).show();
            spinner.setVisibility(View.VISIBLE);

        }


        //  String path= Environment.getExternalStorageDirectory().getAbsolutePath()+"/test/test0.mp4";
     /*  File f=new File(path);
       if(f.exists())
       {
           Toast.makeText(this,path,Toast.LENGTH_LONG).show();
       }
       else
       {
           Toast.makeText(this,"not found",Toast.LENGTH_LONG).show();
       }

       */
      /*  VideoView videoView = (VideoView)findViewById(R.id.VideoView);
        MediaController mediaController= new MediaController(this);
        mediaController.setAnchorView(videoView);

        //specify the location of media file
        Uri uri=Uri.parse(path);

        //Setting MediaController and URI, then starting the videoView
        videoView.setMediaController(mediaController);
        videoView.setVideoURI(uri);
        // videoView.requestFocus();
        videoView.start();*/

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        switch (requestCode) {
            case 1000:
                if (ActivityCompat.checkSelfPermission(PlayActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
                    Log.d("", "");
                else
                    checkPermissions();
                break;
        }
    }

    private void updateList() {
        Handler handler = new Handler();
        int delay = 10000; //milliseconds
        String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/test";
        //  Log.d("Files", "Path: " + path);
        File directory = new File(path);
        files = directory.listFiles();
        playVideo();
//        Log.d("Files", "Size: " + files.length);
        handler.postDelayed(new Runnable() {
            public void run() {
                //do something
                String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/test";
                //  Log.d("Files", "Path: " + path);
                File directory = new File(path);
                files = directory.listFiles();
                //    Log.d("Files", "Size: " + files.length);
                // System.out.println(path);
            }
        }, delay);
    }
}
